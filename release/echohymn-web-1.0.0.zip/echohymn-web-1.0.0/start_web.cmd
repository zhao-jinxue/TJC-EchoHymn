@echo off
chcp 65001 >nul
title EchoHymn Web
echo ============================================
echo   EchoHymn - 赞美诗与颂歌 (Web 本地版)
echo ============================================
echo.

REM 切换到脚本所在目录
cd /d "%~dp0"

REM 寻找可用的 python
set "PYCMD="
where python >nul 2>nul && set "PYCMD=python"
if not defined PYCMD (
    where py >nul 2>nul && set "PYCMD=py -3"
)

if not defined PYCMD (
    echo [错误] 未找到 Python。
    echo 请安装 Python（https://www.python.org/）并勾选 "Add to PATH"，
    echo 或将本目录部署到任意静态服务器后访问。
    echo.
    echo 正在打开本目录（可手动部署到服务器）...
    explorer "%~dp0"
    pause
    exit /b 1
)

echo 使用命令: %PYCMD% -m http.server 8000
echo 浏览器即将打开: http://localhost:8000
echo 按 Ctrl+C 停止服务。
echo.
start "" "http://localhost:8000"
%PYCMD% -m http.server 8000
